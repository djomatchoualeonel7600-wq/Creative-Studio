/* Réglages de Stodium — à modifier ici, nulle part ailleurs.
   demo      : true  = affiche les petits repères orange « Exemple » et « Photo à ajouter ».
               false = site propre, prêt à être montré au public.
   email     : l'adresse qui reçoit les demandes de devis (ex. "contact@mondomaine.fr").
   endpoint  : (facultatif) l'adresse d'un service de formulaire comme Formspree. S'il est rempli, il passe avant l'e-mail.
   whatsapp  : (facultatif) numéro au format international, sans + ni espaces (ex. "33612345678"). */
window.STODIUM = {
  demo: true,
  email: "",
  endpoint: "",
  whatsapp: ""
};
