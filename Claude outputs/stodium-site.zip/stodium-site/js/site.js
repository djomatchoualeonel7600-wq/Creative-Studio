/* Stodium — interactions (aucune bibliothèque) */
(() => {
  const C = Object.assign({ demo: true, email: '', endpoint: '', whatsapp: '' }, window.STODIUM || {});
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (C.demo) document.body.dataset.demo = '1';

  /* ---------- médias : une image/vidéo déposée dans le dossier apparaît toute seule ---------- */
  function loadMedia(m) {
    $$('img,video', m).forEach(n => n.remove());
    m.classList.remove('has');
    const src = m.dataset.img;
    if (src) {
      const im = new Image();
      im.alt = m.dataset.alt || '';
      im.decoding = 'async';
      im.onload = () => { m.prepend(im); m.classList.add('has'); };
      im.src = src;
    }
    if (m.hasAttribute('data-autoplay') && m.dataset.video) attachVideo(m, true);
  }
  function attachVideo(m, play) {
    if (m._v === false) return;
    if (m._v) { if (play) m._v.play().catch(() => {}); return; }
    const v = document.createElement('video');
    v.muted = true; v.loop = true; v.playsInline = true; v.preload = 'auto'; v.setAttribute('aria-hidden', 'true');
    v.onloadeddata = () => { m.append(v); m.classList.add('has'); requestAnimationFrame(() => v.classList.add('on')); if (play) v.play().catch(() => {}); };
    v.onerror = () => { m._v = false; };
    v.src = m.dataset.video;
    m._v = v;
  }
  $$('.media[data-img],.media[data-video]').forEach(loadMedia);
  // vidéo au survol
  $$('[data-hv]').forEach(card => {
    const m = $('.media[data-video]', card);
    if (!m) return;
    card.addEventListener('pointerenter', () => attachVideo(m, true));
    card.addEventListener('pointerleave', () => { if (m._v) { m._v.pause(); } });
    card.addEventListener('focus', () => attachVideo(m, true));
  });

  /* ---------- en-tête ---------- */
  const hd = $('.hd');
  const onScroll = () => {
    hd.classList.toggle('s', scrollY > 30);
    const hm = $('.hero .media');
    if (hm && !reduce && scrollY < innerHeight) hm.style.transform = `translateY(${scrollY * 0.22}px)`;
  };
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  $$('.dd').forEach(dd => {
    const btn = $('button', dd); let t;
    const open = v => { dd.classList.toggle('o', v); btn.setAttribute('aria-expanded', v); };
    dd.addEventListener('pointerenter', () => { clearTimeout(t); open(true); });
    dd.addEventListener('pointerleave', () => { t = setTimeout(() => open(false), 160); });
    btn.addEventListener('click', () => open(!dd.classList.contains('o')));
    addEventListener('keydown', e => { if (e.key === 'Escape') open(false); });
    document.addEventListener('click', e => { if (!dd.contains(e.target)) open(false); });
  });
  const mn = $('.mnav'), bg = $('.burger');
  const setMenu = v => { mn.classList.toggle('o', v); document.body.classList.toggle('lock', v); bg.setAttribute('aria-expanded', v); if (v) $('.x', mn).focus(); else bg.focus(); };
  bg && bg.addEventListener('click', () => setMenu(true));
  $('.x', mn) && $('.x', mn).addEventListener('click', () => setMenu(false));
  $$('a', mn).forEach(a => a.addEventListener('click', () => setMenu(false)));
  addEventListener('keydown', e => { if (e.key === 'Escape' && mn.classList.contains('o')) setMenu(false); });

  /* ---------- transition de page (le trait lumineux) ---------- */
  const beam = $('.beam');
  addEventListener('pageshow', e => { if (e.persisted) beam.classList.remove('go'); });
  document.addEventListener('click', e => {
    const a = e.target.closest('a[href]');
    if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || a.target === '_blank' || a.hasAttribute('download')) return;
    const u = new URL(a.href, location.href);
    if (u.origin !== location.origin && location.protocol !== 'file:') return;
    if (u.protocol === 'mailto:' || u.protocol === 'tel:') return;
    if (u.pathname === location.pathname && u.hash) return;
    if (reduce) return;
    e.preventDefault();
    beam.classList.add('go');
    setTimeout(() => { location.href = a.href; }, 520);
  });

  /* ---------- apparition au défilement ---------- */
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('v'); io.unobserve(e.target); } }), { threshold: .12, rootMargin: '0px 0px -6% 0px' });
  $$('[data-r]').forEach(el => io.observe(el));

  /* ---------- manifeste : les mots s'allument ---------- */
  const big = $('.mani .big');
  if (big) {
    const walk = n => {
      [...n.childNodes].forEach(c => {
        if (c.nodeType === 3) {
          const f = document.createDocumentFragment();
          c.textContent.split(/(\s+)/).forEach(p => { if (!p.trim()) { f.append(p); return; } const s = document.createElement('span'); s.className = 'w'; s.textContent = p; f.append(s); });
          c.replaceWith(f);
        } else if (c.nodeType === 1) { walk(c); if (c.tagName === 'MARK') c.querySelectorAll('.w').forEach(w => w.classList.add('o')); }
      });
    };
    walk(big);
    const ws = $$('.w', big);
    const paint = () => {
      const r = big.getBoundingClientRect();
      const p = Math.min(1, Math.max(0, (innerHeight * .85 - r.top) / (r.height + innerHeight * .35)));
      const n = Math.round(p * ws.length * 1.05);
      ws.forEach((w, i) => w.classList.toggle('on', i < n));
    };
    addEventListener('scroll', paint, { passive: true }); paint();
  }

  /* ---------- process : la ligne se remplit ---------- */
  const proc = $('.proc');
  if (proc) {
    const steps = $$('.pst', proc);
    const upd = () => {
      const r = proc.getBoundingClientRect(), mid = innerHeight * .55;
      proc.style.setProperty('--p', Math.min(1, Math.max(0, (mid - r.top) / r.height)));
      steps.forEach(s => { const b = s.getBoundingClientRect(); s.classList.toggle('on', b.top + b.height * .5 < innerHeight * .78); });
    };
    addEventListener('scroll', upd, { passive: true }); addEventListener('resize', upd); upd();
  }

  /* ---------- FAQ ---------- */
  $$('.fq').forEach(q => {
    const b = $('button', q);
    b.addEventListener('click', () => {
      const o = !q.classList.contains('o');
      $$('.fq.o', q.parentNode).forEach(x => { x.classList.remove('o'); $('button', x).setAttribute('aria-expanded', 'false'); });
      q.classList.toggle('o', o); b.setAttribute('aria-expanded', o);
    });
  });

  /* ---------- « ce que nous produisons » ---------- */
  $$('.prods').forEach(box => {
    const bs = $$('.plist button', box), ps = $$('.pn', box);
    bs.forEach((b, i) => b.addEventListener('click', () => {
      bs.forEach((x, j) => { x.classList.toggle('on', i === j); x.setAttribute('aria-selected', i === j); });
      ps.forEach((p, j) => p.classList.toggle('on', i === j));
    }));
  });

  /* ---------- filtres de projets ---------- */
  const fl = $('.filters');
  if (fl) {
    const cards = $$('.pgrid .pc');
    const apply = f => {
      $$('button', fl).forEach(b => { const on = b.dataset.f === f; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); });
      cards.forEach(c => c.classList.toggle('hide', f !== 'tous' && c.dataset.c !== f));
    };
    $$('button', fl).forEach(b => b.addEventListener('click', () => { apply(b.dataset.f); history.replaceState(null, '', '#' + b.dataset.f); }));
    const h = location.hash.slice(1); apply(['mariage', 'entreprise', 'sport', 'studio'].includes(h) ? h : 'tous');
  }

  /* ---------- fenêtre projet ---------- */
  const mod = $('.mod');
  if (mod && window.PROJECTS) {
    const P = window.PROJECTS; let cur = 0, opener = null;
    const mm = $('.mm', mod);
    const show = i => {
      cur = (i + P.length) % P.length; const p = P[cur];
      mm.dataset.img = p.img; mm.dataset.video = p.video || ''; mm.dataset.alt = p.title; loadMedia(mm);
      $('.mt', mod).textContent = p.title;
      $('.mtg', mod).innerHTML = p.tags.map(t => `<span class="chip">${t}</span>`).join('');
      $('.md', mod).textContent = p.desc;
      $('dl', mod).innerHTML = `<dt>Client</dt><dd class="tbd">${p.client}</dd><dt>Date</dt><dd class="tbd">${p.date}</dd><dt>Lieu</dt><dd class="tbd">${p.place}</dd><dt>Livrables</dt><dd>${p.deliv}</dd>`;
      const cta = $('.mcta', mod);
      cta.href = p.cat === 'studio' ? 'creators.html' : 'contact.html?type=' + p.cat;
      $('.mcta span', mod).textContent = p.cat === 'studio' ? 'Découvrir Stodium Creators' : 'Je veux le même';
    };
    const open = (i, from) => { opener = from; show(i); mod.classList.add('o'); document.body.classList.add('lock'); $('.x', mod).focus(); };
    const close = () => { mod.classList.remove('o'); document.body.classList.remove('lock'); if (mm._v) mm._v.pause(); opener && opener.focus(); };
    $$('[data-p]').forEach(c => c.addEventListener('click', e => { e.preventDefault(); open(P.findIndex(p => p.id === c.dataset.p), c); }));
    $('.x', mod).addEventListener('click', close);
    $('.pv2', mod).addEventListener('click', () => show(cur - 1));
    $('.nx2', mod).addEventListener('click', () => show(cur + 1));
    mod.addEventListener('click', e => { if (e.target === mod) close(); });
    addEventListener('keydown', e => {
      if (!mod.classList.contains('o')) return;
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowRight') show(cur + 1);
      if (e.key === 'ArrowLeft') show(cur - 1);
      if (e.key === 'Tab') {
        const f = $$('button,a[href]', mod).filter(x => x.offsetParent); const a = f[0], z = f[f.length - 1];
        if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); }
        else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
      }
    });
  }

  /* ---------- départ rapide (accueil) ---------- */
  const quick = $('#quick');
  if (quick) {
    quick.addEventListener('submit', e => {
      e.preventDefault();
      const d = new FormData(quick);
      try { sessionStorage.setItem('stodium-quick', JSON.stringify({ type: d.get('type') || '', email: d.get('email') || '', date: d.get('date') || '' })); } catch (_) {}
      beam.classList.add('go'); setTimeout(() => { location.href = 'contact.html'; }, 520);
    });
  }

  /* ---------- formulaire en étapes ---------- */
  const wiz = $('.wiz');
  if (wiz) {
    const form = $('form', wiz), stps = $$('.stp', form), tops = $$('.top button', wiz);
    let n = 0;
    const go = i => {
      n = i;
      stps.forEach((s, j) => s.classList.toggle('on', j === n));
      tops.forEach((t, j) => { t.classList.toggle('on', j === n); t.classList.toggle('ok', j < n); });
      $('.back', form).style.visibility = n ? 'visible' : 'hidden';
      const last = n === stps.length - 1;
      $('.next', form).hidden = last; $('.send', form).hidden = !last;
      $('.cnt', form).textContent = `Étape ${n + 1} sur ${stps.length}`;
      wiz.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    };
    const valid = i => {
      let ok = true, first = null;
      $$('.fld[data-req]', stps[i]).forEach(f => {
        const inputs = $$('input,textarea', f);
        const good = inputs.some(x => (x.type === 'radio' || x.type === 'checkbox') ? x.checked : x.value.trim() && (x.type !== 'email' || /^\S+@\S+\.\S+$/.test(x.value)));
        f.classList.toggle('err', !good);
        if (!good) { ok = false; first = first || inputs[0]; }
      });
      if (first) first.focus({ preventScroll: false });
      return ok;
    };
    $('.next', form).addEventListener('click', () => { if (valid(n)) go(n + 1); });
    $('.back', form).addEventListener('click', () => go(n - 1));
    tops.forEach((t, j) => t.addEventListener('click', () => { if (j <= n || valid(n)) go(j); }));
    form.addEventListener('input', e => e.target.closest('.fld') && e.target.closest('.fld').classList.remove('err'));
    // préremplissage
    const qs = new URLSearchParams(location.search); let q = {};
    try { q = JSON.parse(sessionStorage.getItem('stodium-quick') || '{}'); } catch (_) {}
    const t = qs.get('type') || q.type;
    const map = { mariage: 'Mariage ou cérémonie', entreprise: 'Entreprise ou séminaire', sport: 'Sport ou association', studio: 'Interview, photo pro ou podcast' };
    const want = map[t] || t;
    if (want) $$('input[name=type]', form).forEach(r => { if (r.value === want) r.checked = true; });
    if (q.email) form.email.value = q.email;
    if (q.date) form.date.value = q.date;
    form.addEventListener('submit', async e => {
      e.preventDefault();
      if (!valid(n)) return;
      const d = new FormData(form), lines = [];
      const seen = new Set();
      for (const [k] of d.entries()) {
        if (seen.has(k) || k === 'consent') continue; seen.add(k);
        const lab = $(`[name="${k}"]`, form).closest('.fld'); const title = lab ? ($('label,.lb', lab).childNodes[0].textContent || '').trim() : k;
        const v = d.getAll(k).filter(Boolean).join(', ');
        if (v) lines.push(`${title} : ${v}`);
      }
      const text = 'Demande de devis — Stodium Événements\n\n' + lines.join('\n');
      const done = $('.done', wiz);
      $('pre', done).textContent = text;
      let msg = C.demo ? 'Mode démonstration : rien n’a été envoyé. Renseignez l’e-mail ou le service d’envoi dans js/config.js pour recevoir les demandes.' : 'Merci. Nous revenons vers vous très vite.';
      try {
        if (C.endpoint) { const r = await fetch(C.endpoint, { method: 'POST', headers: { Accept: 'application/json' }, body: d }); msg = r.ok ? 'Merci. Votre demande est bien partie, nous revenons vers vous très vite.' : 'L’envoi n’a pas abouti. Copiez votre demande ci-dessous et envoyez-la nous par e-mail.'; }
        else if (C.email) { location.href = `mailto:${C.email}?subject=${encodeURIComponent('Demande de devis événement')}&body=${encodeURIComponent(text)}`; msg = 'Votre messagerie s’ouvre avec votre demande. Il ne reste qu’à l’envoyer.'; }
      } catch (_) { msg = 'L’envoi n’a pas abouti. Copiez votre demande ci-dessous.'; }
      $('.dm', done).textContent = msg;
      if (C.whatsapp) { const w = $('.wa', done); w.hidden = false; w.href = `https://wa.me/${C.whatsapp}?text=${encodeURIComponent(text)}`; }
      form.hidden = true; $('.top', wiz).hidden = true; done.classList.add('on'); wiz.scrollIntoView({ behavior: 'smooth', block: 'start' });
      $('.copy', done).onclick = async ev => { try { await navigator.clipboard.writeText(text); ev.currentTarget.firstChild.textContent = 'Copié '; } catch (_) {} };
    });
    go(0);
  }
})();
